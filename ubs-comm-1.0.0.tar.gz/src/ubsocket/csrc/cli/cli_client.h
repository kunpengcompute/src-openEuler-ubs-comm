/*
 *Copyright (c) Huawei Technologies Co., Ltd. 2026-2026. All rights reserved.
 *Description: Provide the utility for cli client, etc
 *Author:
 *Create: 2026-02-09
 *Note:
 *History: 2026-02-09
*/

#ifndef CLI_CLIENT
#define CLI_CLIENT

#include "cli_args_parser.h"
#include "profiling/statistics/cli_message.h"

namespace Statistics {
class CLIClient {
public:
    static constexpr size_t maxResponseSize = 32 * 1024 * 1024; // 32M
    static constexpr uint32_t cliclientIoTimeoutMs = 200;

    explicit CLIClient(std::string severPath, int pid)
    {
        mServerPath = severPath + std::to_string(pid);
    }

    ~CLIClient() = default;

    int Query(CLIArgsParser::ParsedArgs &args, CLIMessage &response);

    bool IsServerAvailable();

    int SetSocketTimeout(int sockFd) const;

    int ProcessStat(int sockfd, CLIMessage &response);

    int ProcessFlowControl(int sockfd, CLIMessage &response);

    int ProcessTopo(int sockfd, CLIMessage &response, CLIArgsParser::ParsedArgs &args);

    int ProcessQbufPool(int sockfd, CLIMessage &response);

    int ProcessUmqInfo(int sockfd, CLIMessage &response);

    int ProcessIo(int sockfd, CLIMessage &response);

    int ProcessUmq(int sockfd, CLIMessage &response);

    int ProcessDelayQuery(int sockfd, CLIMessage &response, CLIArgsParser::ParsedArgs &args);

    int ProcessProbeQuery(int sockfd, CLIMessage &response);

private:
    std::string mServerPath;
};
} // namespace Statistics
#endif