/*
 * SPDX-License-Identifier: MIT
 * Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
 * Description: umq lib perftest param process
 * Create: 2024-3-6
 */

#include <getopt.h>
#include <stdio.h>
#include <time.h>
#include <string.h>

#include "umq_perftest_param.h"

// clang-format off
static struct option g_long_options[] = {
    {"dev", required_argument, NULL, 'd'},
    {"test-case", required_argument, NULL, 'c'},
    {"port", required_argument, NULL, 'p'},
    {"local-ip", required_argument, NULL, 'l'},
    {"remote-ip", required_argument, NULL, 'r'},
    {"size", required_argument, NULL, 's'},
    {"cpu_core", required_argument, NULL, 'u'},
    {"feature", required_argument, NULL, 'f'},
    {"help", no_argument, NULL, 'h'},
    /* Long options only */
    {"server", no_argument, NULL, 'S'},
    {"client", no_argument, NULL, 'C'},
    {"trans-mode", required_argument, NULL, 'T'},
    {"rx-depth", required_argument, NULL, 'R'},
    {"tx-depth", required_argument, NULL, 'U'},
    {"tp-mode", required_argument, NULL, 'M'},
    {"tp-type", required_argument, NULL, 'P'},

    {"buf-mode", required_argument, NULL, 'b'},
    {"interrupt", no_argument, NULL, 'I'},
    {"eid-index", required_argument, NULL, 'E'},
    {"use_atomic_window", no_argument, NULL, 'A'},
    {"buf_multiplex", no_argument, NULL, 'B'},
    {"num", required_argument, NULL, 'n'},
    {"enable-perf", no_argument, NULL, 'F'},
    {"blk-size", required_argument, NULL, 'L'},
    {NULL, 0, NULL, 0}
};
// clang-format on

static void usage(void)
{
    (void)printf("Usage:\n");
    (void)printf("  -d, --dev <dev>                     device name <dev>\n");
    (void)printf("  -l, --local-ip <ip-address>         local ip address\n");
    (void)printf("  -r, --remote-ip <ip-address>        remote ip address\n");
    (void)printf("  -p, --port <port>                   listen on/connect to server's port <port>\n");
    (void)printf("  -c, --test-case <case index>        test case to be performed(default: 0)\n");
    (void)printf("                                      0: test umq latency(default)\n");
    (void)printf("                                      1: test umq qps\n");
    (void)printf("  -u, --cpu_core <cpu_core>           from which cpu core to set affinity for each thread\n");
    (void)printf("      --server                        to launch server.\n");
    (void)printf("      --client                        to launch client.\n");

    (void)printf("      --buf-mode                      set umq_buf_mode_t.\n");
    (void)printf("  -f, --feature <feature>             umq feature, 0 for base api, 1 for pro api\n");
    (void)printf("      --interrupt                     set interrupt mode.\n");
    (void)printf("  -s, --size <size>                   size of request, not more than 8192\n");
    (void)printf("      --trans-mode                    set umq_trans_mode_t.\n");
    (void)printf("      --tx-depth                      set queue tx-depth(default 512).\n");
    (void)printf("      --rx-depth                      set queue rx-depth(default 512).\n");
    (void)printf("      --tp-mode                       set queue umq_tp_mode_t(default UMQ_TM_RC).\n");
    (void)printf("      --tp-type                       set queue umq_tp_type_t(default UMQ_TP_TYPE_CTP).\n");
    (void)printf("      --eid-index                     set eid index.\n");
    (void)printf("      --use_atomic_window             use atomic window when enable flow control.\n");
    (void)printf("      --num                           set number of iterations.\n");
    (void)printf("      --enable-perf                   enable perf.\n");
    (void)printf("      --blk-size                      set umq_buf_block_size(default:0), 0=BLOCK_SIZE_4K\n");
    (void)printf("  -h, --help                          show help info.\n\n");
}

static void init_cfg(umq_perftest_config_t *cfg)
{
    perftest_config_t *config = &cfg->config;

    config->tcp_port = DEFAULT_LISTEN_PORT;
    config->case_type = PERFTEST_CASE_LAT;
    config->cpu_affinity = UINT32_MAX;
    config->size = DEFAULT_REQUEST_SIZE_4K;
    config->tx_depth = DEFAULT_DEPTH;
    config->rx_depth = DEFAULT_DEPTH;
    config->interrupt = false;
    config->buf_multiplex = false;

    cfg->buf_mode = UMQ_BUF_SPLIT;
    cfg->trans_mode = UMQ_TRANS_MODE_IB;
    cfg->eid_idx = 0;
    cfg->use_atomic_window = false;
    cfg->enable_perf = false;
    cfg->test_round = DEFAULT_LAT_TEST_ROUND;
    cfg->blk_mode = 0;
    cfg->tp_type = UMQ_TP_TYPE_CTP;
}

static int copy_optarg_to_buf(char *dst, size_t dst_size, const char *opt_name, const char *opt_arg)
{
    int ret = snprintf(dst, dst_size, "%s", opt_arg);
    if (ret < 0 || (size_t)ret >= dst_size) {
        LOG_PRINT("%s is too long\n", opt_name);
        return -1;
    }

    return 0;
}

int umq_perftest_parse_arguments(int argc, char **argv, umq_perftest_config_t *cfg)
{
    if (argc == 1) {
        usage();
        return -1;
    }

    init_cfg(cfg);
    while (1) {
        int c = getopt_long(argc, argv, "c:d:f:l:r:p:u:s:hE:n:L:", g_long_options, NULL);
        if (c == -1) {
            break;
        }

        switch (c) {
            case 'd':
                if (copy_optarg_to_buf(cfg->config.dev_name, sizeof(cfg->config.dev_name), "--dev", optarg) != 0) {
                    return -1;
                }
                break;
            case 'c':
                cfg->config.case_type = (uint32_t)strtoul(optarg, NULL, 0);
                if (cfg->config.case_type >= PERFTEST_CASE_MAX) {
                    LOG_PRINT("get case_type %d failed\n", (int)cfg->config.case_type);
                    return -1;
                }
                break;
            case 'f':
                cfg->feature = (uint32_t)strtoul(optarg, NULL, 0);
                break;
            case 'p':
                cfg->config.tcp_port = (uint16_t)strtoul(optarg, NULL, 0);
                break;
            case 'l':
                if (copy_optarg_to_buf(cfg->config.local_ip, sizeof(cfg->config.local_ip),
                    "--local-ip", optarg) != 0) {
                    return -1;
                }
                break;
            case 'r':
                if (copy_optarg_to_buf(cfg->config.remote_ip, sizeof(cfg->config.remote_ip),
                    "--remote-ip", optarg) != 0) {
                    return -1;
                }
                break;
            case 's':
                cfg->config.size = (uint32_t)strtoul(optarg, NULL, 0);
                break;
            case 'h':
                usage();
                return -1;
            case 'S':
                cfg->config.instance_mode = cfg->config.instance_mode == PERF_INSTANCE_NONE ?
                    PERF_INSTANCE_SERVER : cfg->config.instance_mode;
                break;
            case 'C':
                cfg->config.instance_mode = cfg->config.instance_mode == PERF_INSTANCE_NONE ?
                    PERF_INSTANCE_CLIENT : cfg->config.instance_mode;
                break;
            case 'u':
                cfg->config.cpu_affinity = (uint32_t)strtoul(optarg, NULL, 0);
                break;
            case 'T':
                cfg->trans_mode = (uint32_t)strtoul(optarg, NULL, 0);
                break;
            case 'U':
                cfg->config.tx_depth = (uint32_t)strtoul(optarg, NULL, 0);
                break;
            case 'R':
                cfg->config.rx_depth = (uint32_t)strtoul(optarg, NULL, 0);
                break;
            case 'b':
                cfg->buf_mode = (uint32_t)strtoul(optarg, NULL, 0);
                break;
            case 'I':
                cfg->config.interrupt = true;
                break;
            case 'A':
                cfg->use_atomic_window = true;
                break;
            case 'B':
                cfg->config.buf_multiplex = true;
                break;
            case 'M':
                cfg->tp_mode = (umq_tp_mode_t)strtoul(optarg, NULL, 0);
                if (cfg->tp_mode >= UMQ_TM_MAX) {
                    return -1;
                }
                break;
            case 'P':
                cfg->tp_type = (umq_tp_type_t)strtoul(optarg, NULL, 0);
                if (cfg->tp_type >= UMQ_TP_TYPE_MAX) {
                    return -1;
                }
                break;
            case 'E':
                cfg->eid_idx = (uint16_t)strtoul(optarg, NULL, 0);
                break;
            case 'n':
                cfg->test_round = (uint32_t)strtoul(optarg, NULL, 0);
                break;
            case 'F':
                cfg->enable_perf = true;
                break;
            case 'L':
                cfg->blk_mode = (uint32_t)strtoul(optarg, NULL, 0);
                break;
            default:
                usage();
                return -1;
        }
    }

    if (optind < argc) {
        usage();
        return -1;
    }

    return 0;
}
