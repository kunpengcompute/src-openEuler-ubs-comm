/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2026. All rights reserved.
 * ubs-comm is licensed under the Mulan PSL v2.
 * You can use this software according to the terms and conditions of the Mulan PSL v2.
 * You may obtain a copy of Mulan PSL v2 at:
 *      http://license.coscl.org.cn/MulanPSL2
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY OR FIT FOR A PARTICULAR PURPOSE.
 * See the Mulan PSL v2 for more details.
 */
#include "ubsocket_prof_tracepoint_dumper.h"
#include "ubsocket_prof_tracer.h"

namespace ock {
namespace ubs {
namespace profiling {
void DumpThread::DumpData() noexcept
{
    std::ostringstream oss;
    WriteDumpTitle(oss);
    Tracer::Instance().Combine(oss);
    if (WriteDumpData(oss) != 0) {
        UBS_VLOG_WARN("Profiling data write skipped, please check path and permissions.\n");
        return;
    }
    UBS_VLOG_DEBUG("Dump thread success combiner and dump data");
}
} // namespace profiling
} // namespace ubs
} // namespace ock
