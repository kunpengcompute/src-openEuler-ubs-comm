struct AddrInfo
{
    void *addr = nullptr;
    size_t len = 0;
}
class RingBuffer
{
    // shm used at send
    AddrInfo TxTail;
    AddrInfo TxAddr;

    // shm used at recv
    AddrInfo RxAddr;

    // local variable used at send
    atomic_uint32_t prodHead;
    atomic_uint32_t prodTail;

    // local variable used at recv
    uint32_t cons;
    uint32_t consCnt;
    uint32_t updateLim; // consCnt >= updateLim, write TxTail

    // local variable used at epoll_wait
    
}