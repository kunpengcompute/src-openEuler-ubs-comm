/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2025. All rights reserved.
 
 * ubs-hcom is licensed under the Mulan PSL v2.
 * You can use this software according to the terms and conditions of the Mulan PSL v2.
 * You may obtain a copy of Mulan PSL v2 at:
 *      http://license.coscl.org.cn/MulanPSL2
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY OR FIT FOR A PARTICULAR PURPOSE.
 * See the Mulan PSL v2 for more details.
 */

package com.huawei.ock.hcom.test.service;

import com.huawei.ock.hcom.service.NetOobUDSListenOptions;

import org.junit.Test;

/**
 * class NetOobUDSListenOptions test
 *
 * @since 2024-02-17
 */
public class NetOobUDSListenOptionsTest {
    @Test(expected = Exception.class)
    public void validateTest_Execption() throws Exception {
        NetOobUDSListenOptions udsOpt1 = new NetOobUDSListenOptions();
        udsOpt1.name = "yyyyy";
        udsOpt1.validate();

        NetOobUDSListenOptions udsOpt = new NetOobUDSListenOptions();
        udsOpt.validate();
    }
}
